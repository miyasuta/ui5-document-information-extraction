sap.ui.define(["sap/m/MessageBox", "./BaseController", "sap/m/MessageToast", "sap/ui/model/json/JSONModel"], function (MessageBox, __BaseController, MessageToast, JSONModel) {
  function _interopRequireDefault(obj) {
    return obj && obj.__esModule && typeof obj.default !== "undefined" ? obj.default : obj;
  }

  const BaseController = _interopRequireDefault(__BaseController);

  /**
   * @namespace miyasuta.ui5die.controller
   */
  const Main = BaseController.extend("miyasuta.ui5die.controller.Main", {
    onInit: function _onInit() {
      const oModel = {};
      this.getView().setModel(new JSONModel(oModel), "invoice");
      const oModel2 = {
        editable: false,
        refreshEnabled: false,
        uploadEnabled: false
      };
      this.getView().setModel(new JSONModel(oModel2), "viewModel");
    },
    handleUploadPress: async function _handleUploadPress() {
      if (this._jobId) {
        MessageBox.confirm(this.getResourceBundle().getText("confirmText"), {
          onClose: async oAction => {
            if (oAction === "OK") {
              this._resetData();

              await this._uploadImage();
            }
          }
        });
      } else {
        await this._uploadImage();
      }
    },
    onFileChange: function _onFileChange() {
      const oFileUploader = this.byId("fileUploader");

      if (oFileUploader.getValue()) {
        this.getView().getModel("viewModel").setProperty("/uploadEnabled", true);
      }
    },
    onRefresh: async function _onRefresh() {
      // eslint-disable-next-line @typescript-eslint/no-unsafe-assignment
      const response = await this._getStatus();

      if (response.status === "DONE") {
        this._setInvoiceData(response.extraction);

        const viewModel = this.getView().getModel("viewModel");
        viewModel.setProperty("/refreshEnabled", false);
        viewModel.setProperty("/editable", true);
      } else if (response.status === "PENDING") {
        MessageToast.show(this.getResourceBundle().getText("pendingText"));
      }
    },
    onSave: function _onSave() {
      MessageToast.show(this.getResourceBundle().getText("saveText"));
    },
    _resetData: function _resetData() {
      this.getView().getModel("invoice").setData({});
      this._jobId = "";
    },
    _uploadImage: async function _uploadImage() {
      //prepare form data
      const oFileUploader = this.byId("fileUploader");
      const oUploadedFile = oFileUploader.oFileUpload.files[0];
      const blob = new Blob([oUploadedFile], {
        type: oUploadedFile.type
      });
      const formData = new FormData();
      formData.append("file", blob, oUploadedFile.name);
      const options = this.getOwnerComponent().getModel("options").getData();
      formData.append('options', JSON.stringify(options)); //call die

      const response = await this._postToDie(formData);
      this._jobId = response.id; // enable refresh button

      this.getView().getModel("viewModel").setProperty("/refreshEnabled", true);
    },
    _postToDie: async function _postToDie(formData) {
      const dieUrl = this._getbaseUrl() + "/document/jobs";
      const response = await fetch(dieUrl, {
        method: 'POST',
        body: formData
      }); // eslint-disable-next-line @typescript-eslint/no-unsafe-return

      return response.json();
    },
    _getStatus: async function _getStatus() {
      const dieUrl = this._getbaseUrl() + "/document/jobs" + "/" + this._jobId;

      const response = await fetch(dieUrl, {
        method: 'GET'
      });
      return response.json();
    },
    _getbaseUrl: function _getbaseUrl() {
      const appId = this.getOwnerComponent().getManifestEntry("/sap.app/id");
      const appPath = appId.replaceAll(".", "/");
      const appModulePath = jQuery.sap.getModulePath(appPath);
      return appModulePath + "/doc-info-extraction";
    },
    _setInvoiceData: function _setInvoiceData(extractedData) {
      const invoice = {}; //set header

      const invoiceHeader = extractedData.headerFields.reduce((acc, curr) => {
        acc[curr.name] = curr.value;
        return acc;
      }, {}); //set items

      const invoiceItems = extractedData.lineItems.reduce((acc, item) => {
        const lineItem = item.reduce((acc, curr) => {
          acc[curr.name] = curr.value;
          return acc;
        }, {});
        acc.push(lineItem);
        return acc;
      }, []);
      invoice["header"] = invoiceHeader;
      invoice["items"] = invoiceItems;
      this.getView().getModel("invoice").setData(invoice);
    }
  });
  return Main;
});
//# sourceMappingURL=Main.controller.js.map